
export type SportType = 'Soccer' | 'Basketball' | 'Tennis' | 'Esports' | 'MMA';

export interface Odds {
  home: number;
  draw?: number;
  away: number;
}

export interface Match {
  id: string;
  sport: SportType;
  league: string;
  homeTeam: string;
  awayTeam: string;
  time: string;
  isLive: boolean;
  score?: string;
  odds: Odds;
}

export interface BetSelection {
  matchId: string;
  matchName: string;
  selectionName: string; // "Home", "Draw", "Away"
  odds: number;
}

export interface CasinoGame {
  id: string;
  name: string;
  category: 'Slots' | 'Table' | 'Live';
  image: string;
  isNew?: boolean;
  isPopular?: boolean;
}

export enum ViewMode {
  SPORTS = 'SPORTS',
  CASINO = 'CASINO',
  LIVE = 'LIVE'
}
