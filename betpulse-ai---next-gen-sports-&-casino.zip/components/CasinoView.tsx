
import React, { useState } from 'react';
import { CasinoGame } from '../types';
import { Flame, Star, Clock, Trophy, Play } from 'lucide-react';

interface CasinoViewProps {
  games: CasinoGame[];
}

const CasinoView: React.FC<CasinoViewProps> = ({ games }) => {
  const [activeTab, setActiveTab] = useState('All');

  const tabs = ['All', 'Slots', 'Table', 'Live'];

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      {/* Featured Header */}
      <section className="relative h-64 rounded-3xl overflow-hidden">
        <img 
          src="https://picsum.photos/seed/casino/1200/400" 
          alt="Casino Promo" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent flex flex-col justify-end p-8">
          <div className="flex items-center gap-2 mb-2">
            <Flame className="text-orange-500" size={20} fill="currentColor" />
            <span className="text-xs font-black uppercase tracking-widest text-orange-500">Jackpot reaching R$ 1,500,000</span>
          </div>
          <h2 className="text-4xl font-black text-white">THE BIG BASS BONANZA</h2>
          <p className="text-slate-300 mt-2 max-w-sm">Dive into the deep end and fish for massive prizes with 10% cash back today.</p>
        </div>
      </section>

      {/* Category Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
        {tabs.map(tab => (
          <button 
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`
              px-6 py-2.5 rounded-2xl border transition-all flex-shrink-0 font-bold text-sm
              ${activeTab === tab ? 'bg-orange-500 border-orange-500 text-white' : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'}
            `}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Game Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4">
        {games
          .filter(g => activeTab === 'All' || g.category === activeTab)
          .map(game => (
          <div key={game.id} className="group cursor-pointer">
            <div className="relative aspect-[3/4] rounded-2xl overflow-hidden mb-3 border border-slate-800 group-hover:border-orange-500 transition-colors">
              <img 
                src={game.image} 
                alt={game.name} 
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <div className="w-12 h-12 bg-orange-500 rounded-full flex items-center justify-center text-white scale-0 group-hover:scale-100 transition-transform duration-300 shadow-xl shadow-orange-500/30">
                  <Play size={24} fill="currentColor" className="ml-1" />
                </div>
              </div>
              {game.isNew && (
                <div className="absolute top-2 right-2 bg-emerald-500 text-white text-[8px] font-black px-1.5 py-0.5 rounded uppercase tracking-tighter shadow-lg">New</div>
              )}
              {game.isPopular && (
                <div className="absolute top-2 left-2 bg-orange-500 text-white text-[8px] font-black px-1.5 py-0.5 rounded uppercase tracking-tighter shadow-lg">Hot</div>
              )}
            </div>
            <h4 className="text-sm font-bold text-slate-200 truncate group-hover:text-orange-500 transition-colors">{game.name}</h4>
            <p className="text-[10px] text-slate-500 font-medium uppercase tracking-wider">{game.category}</p>
          </div>
        ))}
      </div>

      {/* Casino Stats */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-8">
        <div className="bg-slate-900/50 p-6 rounded-3xl border border-slate-800 flex items-center gap-4">
          <div className="w-12 h-12 bg-purple-500/10 text-purple-500 rounded-2xl flex items-center justify-center">
            <Trophy size={24} />
          </div>
          <div>
            <p className="text-slate-400 text-xs font-bold uppercase tracking-widest">Recent Win</p>
            <p className="text-lg font-black text-white">R$ 12,450.00</p>
            <p className="text-[10px] text-slate-500">Player: @lucas_99</p>
          </div>
        </div>
        <div className="bg-slate-900/50 p-6 rounded-3xl border border-slate-800 flex items-center gap-4">
          <div className="w-12 h-12 bg-orange-500/10 text-orange-500 rounded-2xl flex items-center justify-center">
            <Flame size={24} />
          </div>
          <div>
            <p className="text-slate-400 text-xs font-bold uppercase tracking-widest">Active Players</p>
            <p className="text-lg font-black text-white">4,829</p>
            <p className="text-[10px] text-emerald-500">+12% from last hour</p>
          </div>
        </div>
        <div className="bg-slate-900/50 p-6 rounded-3xl border border-slate-800 flex items-center gap-4">
          <div className="w-12 h-12 bg-blue-500/10 text-blue-500 rounded-2xl flex items-center justify-center">
            <Star size={24} />
          </div>
          <div>
            <p className="text-slate-400 text-xs font-bold uppercase tracking-widest">RTP Average</p>
            <p className="text-lg font-black text-white">96.8%</p>
            <p className="text-[10px] text-slate-500">Across all providers</p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default CasinoView;
