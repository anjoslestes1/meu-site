
import React, { useState } from 'react';
import { BetSelection } from '../types';
import { Trash2, ShoppingBag, X, Zap, ChevronUp, ChevronDown } from 'lucide-react';

interface BettingSlipProps {
  items: BetSelection[];
  onRemove: (id: string) => void;
  onClear: () => void;
  balance: number;
}

const BettingSlip: React.FC<BettingSlipProps> = ({ items, onRemove, onClear, balance }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [stake, setStake] = useState<string>('10');

  const totalOdds = items.reduce((acc, curr) => acc * curr.odds, 1);
  const potentialWinnings = parseFloat(stake || '0') * totalOdds;

  if (items.length === 0 && !isOpen) return null;

  return (
    <>
      {/* Mobile Sticky Summary */}
      <div className="fixed bottom-0 left-0 right-0 md:hidden z-50 px-4 pb-4">
        <button 
          onClick={() => setIsOpen(!isOpen)}
          className="w-full bg-orange-500 text-white py-4 rounded-2xl flex items-center justify-between px-6 shadow-2xl shadow-orange-500/30"
        >
          <div className="flex items-center gap-3">
            <div className="bg-white/20 p-1.5 rounded-lg">
              <ShoppingBag size={18} />
            </div>
            <span className="font-bold">Bet Slip ({items.length})</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs opacity-80">Potential:</span>
            <span className="font-black">R$ {potentialWinnings.toFixed(2)}</span>
            {isOpen ? <ChevronDown size={20} /> : <ChevronUp size={20} />}
          </div>
        </button>
      </div>

      {/* Actual Slip Sidebar */}
      <div className={`
        fixed inset-y-0 right-0 z-50 w-full md:w-80 bg-slate-900 border-l border-slate-800 transition-transform duration-500 transform
        ${isOpen || items.length > 0 ? 'translate-x-0' : 'translate-x-full'} 
        ${!isOpen && 'hidden md:block'}
      `}>
        <div className="flex flex-col h-full">
          <div className="p-6 border-b border-slate-800 flex items-center justify-between bg-slate-900/50 backdrop-blur-md">
            <div className="flex items-center gap-3">
              <ShoppingBag className="text-orange-500" size={20} />
              <h2 className="text-lg font-bold">Bet Slip</h2>
              <span className="bg-orange-500 text-white text-[10px] font-black px-1.5 py-0.5 rounded-full">{items.length}</span>
            </div>
            <button onClick={() => setIsOpen(false)} className="md:hidden p-2 hover:bg-slate-800 rounded-lg">
              <X size={20} />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto custom-scrollbar p-4 space-y-3">
            {items.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-slate-500 text-center gap-4 px-6">
                <div className="w-16 h-16 bg-slate-800 rounded-full flex items-center justify-center">
                  <ShoppingBag size={32} className="opacity-20" />
                </div>
                <div>
                  <p className="font-bold text-slate-300">Your slip is empty</p>
                  <p className="text-xs mt-1">Add some events to start building your combination bet.</p>
                </div>
              </div>
            ) : (
              items.map((item) => (
                <div key={item.matchId} className="bg-slate-800/50 rounded-2xl p-4 border border-slate-700/50 group">
                  <div className="flex justify-between items-start mb-2">
                    <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">{item.matchName}</span>
                    <button onClick={() => onRemove(item.matchId)} className="text-slate-500 hover:text-red-400 transition-colors">
                      <Trash2 size={14} />
                    </button>
                  </div>
                  <div className="flex justify-between items-end">
                    <div className="flex flex-col">
                      <span className="text-xs text-slate-500">Pick: <span className="text-white font-bold">{item.selectionName}</span></span>
                    </div>
                    <span className="text-base font-black text-orange-500">@{item.odds.toFixed(2)}</span>
                  </div>
                </div>
              ))
            )}
          </div>

          {items.length > 0 && (
            <div className="p-6 border-t border-slate-800 bg-slate-900/80 backdrop-blur-md space-y-4">
              <div className="flex items-center justify-between text-xs text-slate-400 uppercase font-bold tracking-widest">
                <span>Total Odds</span>
                <span className="text-lg text-white font-black">@{totalOdds.toFixed(2)}</span>
              </div>
              
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 font-bold text-sm">R$</span>
                <input 
                  type="number" 
                  value={stake}
                  onChange={(e) => setStake(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-2xl py-3 pl-10 pr-4 focus:outline-none focus:ring-2 focus:ring-orange-500/50 text-white font-bold"
                  placeholder="Stake"
                />
              </div>

              <div className="bg-emerald-500/5 rounded-2xl p-4 border border-emerald-500/20">
                <div className="flex justify-between text-[10px] text-emerald-500 font-black uppercase tracking-wider mb-1">
                  <span>Potential Win</span>
                  <span>{items.length > 1 ? `Accumulator Boost Applied` : ''}</span>
                </div>
                <div className="text-2xl font-black text-emerald-400">
                  R$ {potentialWinnings.toFixed(2)}
                </div>
              </div>

              <button 
                disabled={parseFloat(stake) > balance || items.length === 0}
                className="w-full bg-orange-500 hover:bg-orange-600 disabled:bg-slate-800 disabled:opacity-50 disabled:cursor-not-allowed text-white py-4 rounded-2xl font-black text-sm uppercase tracking-widest transition-all active:scale-95 shadow-xl shadow-orange-500/20 flex items-center justify-center gap-2"
              >
                <Zap size={18} fill="currentColor" /> Place Bet
              </button>
              
              <button onClick={onClear} className="w-full text-xs text-slate-500 font-bold hover:text-slate-300 transition-colors">
                Clear all selections
              </button>
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default BettingSlip;
