
import React, { useState, useEffect } from 'react';
import { Match, BetSelection } from '../types';
import { Zap, Clock, TrendingUp, Info } from 'lucide-react';
import { getMatchInsight } from '../services/geminiService';

interface MatchCardProps {
  match: Match;
  onSelect: (selection: BetSelection) => void;
  currentSelection?: string;
}

const MatchCard: React.FC<MatchCardProps> = ({ match, onSelect, currentSelection }) => {
  const [insight, setInsight] = useState<string | null>(null);
  const [loadingInsight, setLoadingInsight] = useState(false);
  const [showInsight, setShowInsight] = useState(false);

  const handleFetchInsight = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (insight) {
      setShowInsight(!showInsight);
      return;
    }
    setLoadingInsight(true);
    setShowInsight(true);
    const result = await getMatchInsight(match);
    setInsight(result);
    setLoadingInsight(false);
  };

  const handleSelection = (name: string, odds: number) => {
    onSelect({
      matchId: match.id,
      matchName: `${match.homeTeam} vs ${match.awayTeam}`,
      selectionName: name,
      odds
    });
  };

  return (
    <div className="bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all rounded-3xl p-5 group flex flex-col gap-4 relative">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          {match.isLive ? (
            <div className="flex items-center gap-1.5 px-2 py-1 rounded bg-red-500/10 text-red-500 text-[10px] font-bold uppercase animate-pulse">
              <Zap size={10} fill="currentColor" /> Live
            </div>
          ) : (
            <div className="flex items-center gap-1.5 px-2 py-1 rounded bg-slate-800 text-slate-400 text-[10px] font-bold uppercase">
              <Clock size={10} /> {match.time}
            </div>
          )}
          <span className="text-xs text-slate-500 font-medium">{match.league}</span>
        </div>
        
        <button 
          onClick={handleFetchInsight}
          className={`
            p-1.5 rounded-lg border transition-all flex items-center gap-1 text-[10px] font-bold uppercase
            ${showInsight ? 'bg-orange-500 text-white border-orange-500' : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-orange-500 hover:border-orange-500'}
          `}
        >
          <Info size={12} /> AI Insight
        </button>
      </div>

      {showInsight && (
        <div className="bg-slate-800/80 rounded-xl p-3 border border-orange-500/30 text-xs text-slate-300 animate-in fade-in slide-in-from-top-2 duration-300">
          <div className="flex items-center gap-2 mb-1 text-orange-400 font-bold uppercase tracking-wider text-[10px]">
            <Zap size={10} /> Gemini Smart Analysis
          </div>
          {loadingInsight ? (
            <div className="flex gap-1">
              <div className="w-1.5 h-1.5 bg-slate-500 rounded-full animate-bounce"></div>
              <div className="w-1.5 h-1.5 bg-slate-500 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
              <div className="w-1.5 h-1.5 bg-slate-500 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
            </div>
          ) : (
            <p className="leading-relaxed">{insight}</p>
          )}
        </div>
      )}

      <div className="flex items-center justify-between">
        <div className="flex flex-col gap-2">
          <div className="flex items-center gap-3">
            <span className="text-base font-bold text-slate-100">{match.homeTeam}</span>
            {match.isLive && <span className="text-base font-black text-orange-500 tracking-widest">{match.score?.split('-')[0].trim()}</span>}
          </div>
          <div className="flex items-center gap-3">
            <span className="text-base font-bold text-slate-100">{match.awayTeam}</span>
            {match.isLive && <span className="text-base font-black text-orange-500 tracking-widest">{match.score?.split('-')[1].trim()}</span>}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-2">
        <OddButton 
          label="1" 
          value={match.odds.home} 
          active={currentSelection === 'Home'} 
          onClick={() => handleSelection('Home', match.odds.home)} 
        />
        {match.odds.draw ? (
          <OddButton 
            label="X" 
            value={match.odds.draw} 
            active={currentSelection === 'Draw'} 
            onClick={() => handleSelection('Draw', match.odds.draw!)} 
          />
        ) : <div />}
        <OddButton 
          label="2" 
          value={match.odds.away} 
          active={currentSelection === 'Away'} 
          onClick={() => handleSelection('Away', match.odds.away)} 
        />
      </div>
    </div>
  );
};

const OddButton: React.FC<{ label: string, value: number, active?: boolean, onClick: () => void }> = ({ label, value, active, onClick }) => (
  <button 
    onClick={onClick}
    className={`
      flex flex-col items-center justify-center py-2.5 rounded-xl border transition-all active:scale-95
      ${active 
        ? 'bg-orange-500 border-orange-500 text-white shadow-lg shadow-orange-500/20' 
        : 'bg-slate-800/40 border-slate-700 text-slate-400 hover:border-slate-500 hover:bg-slate-800'}
    `}
  >
    <span className="text-[10px] font-bold text-slate-500 uppercase">{label}</span>
    <span className={`text-sm font-black ${active ? 'text-white' : 'text-slate-100'}`}>{value.toFixed(2)}</span>
  </button>
);

export default MatchCard;
