
import React, { useState, useEffect, useMemo } from 'react';
import { 
  Trophy, 
  Gamepad2, 
  CircleDollarSign, 
  LayoutDashboard, 
  History, 
  Search, 
  Bell, 
  Menu, 
  X, 
  Zap, 
  ChevronRight,
  TrendingUp,
  Dices,
  Flame,
  User
} from 'lucide-react';
import { ViewMode, Match, BetSelection, CasinoGame } from './types';
import { INITIAL_MATCHES, CASINO_GAMES } from './constants';
import MatchCard from './components/MatchCard';
import BettingSlip from './components/BettingSlip';
import CasinoView from './components/CasinoView';

const App: React.FC = () => {
  const [view, setView] = useState<ViewMode>(ViewMode.SPORTS);
  const [balance, setBalance] = useState<number>(1250.75);
  const [betSlip, setBetSlip] = useState<BetSelection[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const addToSlip = (selection: BetSelection) => {
    setBetSlip(prev => {
      const exists = prev.find(b => b.matchId === selection.matchId);
      if (exists) return prev.map(b => b.matchId === selection.matchId ? selection : b);
      return [...prev, selection];
    });
  };

  const removeFromSlip = (matchId: string) => {
    setBetSlip(prev => prev.filter(b => b.matchId !== matchId));
  };

  const clearSlip = () => setBetSlip([]);

  const filteredMatches = useMemo(() => {
    return INITIAL_MATCHES.filter(m => 
      m.homeTeam.toLowerCase().includes(searchTerm.toLowerCase()) ||
      m.awayTeam.toLowerCase().includes(searchTerm.toLowerCase()) ||
      m.league.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [searchTerm]);

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-slate-950 text-slate-100">
      {/* Sidebar - Mobile drawer / Desktop static */}
      <aside className={`
        fixed inset-y-0 left-0 z-50 w-64 bg-slate-900 border-r border-slate-800 transition-transform duration-300 transform
        ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0 md:static md:block
      `}>
        <div className="flex flex-col h-full">
          <div className="p-6 flex items-center gap-3">
            <div className="w-10 h-10 bg-orange-500 rounded-xl flex items-center justify-center shadow-lg shadow-orange-500/20">
              <Trophy className="text-white w-6 h-6" />
            </div>
            <h1 className="text-xl font-bold tracking-tight text-white">BetPulse<span className="text-orange-500">AI</span></h1>
          </div>

          <nav className="flex-1 px-4 space-y-2 mt-4 overflow-y-auto custom-scrollbar">
            <SidebarItem 
              icon={<LayoutDashboard size={20} />} 
              label="Overview" 
              active={view === ViewMode.SPORTS} 
              onClick={() => { setView(ViewMode.SPORTS); setSidebarOpen(false); }} 
            />
            <SidebarItem 
              icon={<Zap size={20} />} 
              label="Live Events" 
              active={view === ViewMode.LIVE} 
              onClick={() => { setView(ViewMode.LIVE); setSidebarOpen(false); }} 
            />
            <SidebarItem 
              icon={<Dices size={20} />} 
              label="Casino" 
              active={view === ViewMode.CASINO} 
              onClick={() => { setView(ViewMode.CASINO); setSidebarOpen(false); }} 
            />
            
            <div className="pt-6 pb-2 px-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Popular Leagues
            </div>
            <SidebarItem icon={<div className="w-5 h-5 flex items-center justify-center text-xs font-bold border border-slate-700 rounded">PL</div>} label="Premier League" onClick={() => {}} />
            <SidebarItem icon={<div className="w-5 h-5 flex items-center justify-center text-xs font-bold border border-slate-700 rounded">CL</div>} label="Champions League" onClick={() => {}} />
            <SidebarItem icon={<div className="w-5 h-5 flex items-center justify-center text-xs font-bold border border-slate-700 rounded">NBA</div>} label="NBA" onClick={() => {}} />
          </nav>

          <div className="p-4 border-t border-slate-800">
            <div className="bg-slate-800/50 rounded-2xl p-4 flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white">
                <User size={20} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">Cristiano R.</p>
                <p className="text-xs text-slate-400">Pro Account</p>
              </div>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col h-screen overflow-hidden">
        {/* Header */}
        <header className={`
          sticky top-0 z-40 px-4 md:px-8 py-4 flex items-center justify-between transition-all duration-300
          ${isScrolled ? 'glass-effect shadow-xl' : 'bg-transparent'}
        `}>
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setSidebarOpen(true)}
              className="md:hidden p-2 hover:bg-slate-800 rounded-lg"
            >
              <Menu size={24} />
            </button>
            <div className="relative group hidden sm:block">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-orange-500 transition-colors" size={18} />
              <input 
                type="text" 
                placeholder="Search teams, leagues..." 
                className="bg-slate-900 border border-slate-800 rounded-full py-2 pl-10 pr-4 w-64 focus:outline-none focus:ring-2 focus:ring-orange-500/50 transition-all text-sm"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>

          <div className="flex items-center gap-3 md:gap-6">
            <div className="hidden sm:flex flex-col items-end">
              <span className="text-xs text-slate-400 font-medium">Balance</span>
              <span className="text-lg font-bold text-emerald-400">R$ {balance.toLocaleString()}</span>
            </div>
            <div className="flex items-center gap-2">
              <button className="bg-orange-500 hover:bg-orange-600 text-white px-4 md:px-6 py-2 rounded-full font-bold text-sm transition-transform active:scale-95 shadow-lg shadow-orange-500/20">
                Deposit
              </button>
              <button className="p-2 hover:bg-slate-800 rounded-full text-slate-400 relative">
                <Bell size={20} />
                <span className="absolute top-1 right-1 w-2 h-2 bg-orange-500 rounded-full border-2 border-slate-900"></span>
              </button>
            </div>
          </div>
        </header>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto custom-scrollbar p-4 md:p-8 space-y-8 pb-24 md:pb-8">
          {view === ViewMode.SPORTS || view === ViewMode.LIVE ? (
            <>
              {/* Hero Banner */}
              <section className="relative h-48 md:h-64 rounded-3xl overflow-hidden group">
                <img 
                  src="https://picsum.photos/seed/sports/1200/400" 
                  alt="Sports Banner" 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-950/40 to-transparent flex flex-col justify-center p-8">
                  <span className="inline-block bg-orange-500 text-white text-[10px] font-bold px-2 py-1 rounded uppercase tracking-wider mb-2">Promotion</span>
                  <h2 className="text-3xl md:text-4xl font-black text-white max-w-md leading-tight">WIN UP TO 100% EXTRA ON ACCAS</h2>
                  <p className="text-slate-300 mt-2 max-w-sm hidden md:block">Combine 3 or more selections and get massive boosts on your winnings.</p>
                  <button className="mt-6 bg-white text-slate-950 px-6 py-2.5 rounded-full font-bold text-sm w-fit hover:bg-orange-500 hover:text-white transition-colors">
                    Join Now
                  </button>
                </div>
              </section>

              {/* Match Feed */}
              <section>
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-3">
                    <TrendingUp className="text-orange-500" />
                    <h3 className="text-xl font-bold">{view === ViewMode.LIVE ? 'Live Matches' : 'Top Recommendations'}</h3>
                  </div>
                  <div className="flex gap-2">
                    {['All', 'Soccer', 'Basketball', 'Tennis'].map(cat => (
                      <button key={cat} className="px-4 py-1.5 rounded-full bg-slate-900 border border-slate-800 text-sm hover:border-orange-500 transition-colors">
                        {cat}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  {(view === ViewMode.LIVE ? filteredMatches.filter(m => m.isLive) : filteredMatches).map(match => (
                    <MatchCard 
                      key={match.id} 
                      match={match} 
                      onSelect={(sel) => addToSlip(sel)}
                      currentSelection={betSlip.find(b => b.matchId === match.id)?.selectionName}
                    />
                  ))}
                  {filteredMatches.length === 0 && (
                    <div className="col-span-full py-12 text-center text-slate-500 italic">
                      No matches found matching your search.
                    </div>
                  )}
                </div>
              </section>
            </>
          ) : (
            <CasinoView games={CASINO_GAMES} />
          )}
        </div>
      </main>

      {/* Betting Slip Sidebar (Desktop) / Drawer (Mobile) */}
      <BettingSlip 
        items={betSlip} 
        onRemove={removeFromSlip} 
        onClear={clearSlip}
        balance={balance}
      />

      {/* Mobile Nav Overlay Toggle */}
      {sidebarOpen && <div className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm md:hidden" onClick={() => setSidebarOpen(false)}></div>}
    </div>
  );
};

interface SidebarItemProps {
  icon: React.ReactNode;
  label: string;
  active?: boolean;
  onClick: () => void;
}

const SidebarItem: React.FC<SidebarItemProps> = ({ icon, label, active, onClick }) => (
  <button 
    onClick={onClick}
    className={`
      w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all
      ${active 
        ? 'bg-orange-500/10 text-orange-500 font-bold' 
        : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'}
    `}
  >
    {icon}
    <span className="text-sm">{label}</span>
    {active && <div className="ml-auto w-1.5 h-1.5 bg-orange-500 rounded-full shadow-[0_0_8px_rgba(249,115,22,0.6)]"></div>}
  </button>
);

export default App;
