
import { GoogleGenAI } from "@google/genai";
import { Match } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getMatchInsight = async (match: Match) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Provide a very brief 2-sentence expert betting insight for a match between ${match.homeTeam} and ${match.awayTeam} in the ${match.league}. Current odds: Home(${match.odds.home}), Away(${match.odds.away}). ${match.isLive ? `Live score is ${match.score}.` : 'Pre-match analysis.'} Focus on momentum and high-value potential. Output as plain text.`,
      config: {
        temperature: 0.7,
        maxOutputTokens: 100,
      }
    });
    return response.text || "No AI insights available for this match currently.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Error loading AI prediction.";
  }
};
