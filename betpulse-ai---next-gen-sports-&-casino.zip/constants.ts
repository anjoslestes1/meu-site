
import { Match, CasinoGame } from './types';

export const INITIAL_MATCHES: Match[] = [
  {
    id: '1',
    sport: 'Soccer',
    league: 'Premier League',
    homeTeam: 'Arsenal',
    awayTeam: 'Liverpool',
    time: '20:45',
    isLive: true,
    score: '1 - 1',
    odds: { home: 2.15, draw: 3.40, away: 2.80 }
  },
  {
    id: '2',
    sport: 'Soccer',
    league: 'La Liga',
    homeTeam: 'Real Madrid',
    awayTeam: 'Barcelona',
    time: '21:00',
    isLive: false,
    odds: { home: 1.95, draw: 3.60, away: 3.20 }
  },
  {
    id: '3',
    sport: 'Basketball',
    league: 'NBA',
    homeTeam: 'LA Lakers',
    awayTeam: 'Golden State',
    time: '02:30',
    isLive: false,
    odds: { home: 1.85, away: 1.95 }
  },
  {
    id: '4',
    sport: 'Tennis',
    league: 'Australian Open',
    homeTeam: 'N. Djokovic',
    awayTeam: 'C. Alcaraz',
    time: '15:20',
    isLive: true,
    score: '2 - 1',
    odds: { home: 1.65, away: 2.25 }
  },
  {
    id: '5',
    sport: 'Soccer',
    league: 'Brasileirão',
    homeTeam: 'Flamengo',
    awayTeam: 'Palmeiras',
    time: '18:30',
    isLive: false,
    odds: { home: 2.10, draw: 3.10, away: 3.00 }
  }
];

export const CASINO_GAMES: CasinoGame[] = [
  { id: 'c1', name: 'Gates of Olympus', category: 'Slots', image: 'https://picsum.photos/seed/olympus/300/200', isPopular: true },
  { id: 'c2', name: 'Sweet Bonanza', category: 'Slots', image: 'https://picsum.photos/seed/candy/300/200', isNew: true },
  { id: 'c3', name: 'European Roulette', category: 'Table', image: 'https://picsum.photos/seed/roulette/300/200', isPopular: true },
  { id: 'c4', name: 'Speed Blackjack', category: 'Live', image: 'https://picsum.photos/seed/blackjack/300/200' },
  { id: 'c5', name: 'Wolf Gold', category: 'Slots', image: 'https://picsum.photos/seed/wolf/300/200' },
  { id: 'c6', name: 'Sugar Rush', category: 'Slots', image: 'https://picsum.photos/seed/sugar/300/200', isNew: true }
];
